﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RafaelHernandezGomez.Model.Product;
using RafaelHernandezGomez.Model.ShoppingBasket;

namespace RafaelHernandezGomez.Pages
{
    public class IndexModel : PageModel
    {
        // Propiedades para pasar datos a la vista
        public ShoppingBasket ShoppingBasket1 { get; set; }
        public ShoppingBasket ShoppingBasket2 { get; set; }
        public ShoppingBasket ShoppingBasket3 { get; set; }
        public List<Product> ShoppingList1 { get; set; }
        public List<Product> ShoppingList2 { get; set; }
        public List<Product> ShoppingList3 { get; set; }


        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        // Método para crear y registrar productos en la cesta
        private ShoppingBasket ProcessShoppingList(List<Product> shoppingList, string listName)
        {
            _logger.LogInformation($"{listName}:");

            // Loggear la lista de productos
            foreach (var item in shoppingList)
            {
                _logger.LogInformation($"- {item.Name}: {item.Weight} kg, quantity: {item.Quantity}");
            }

            // Crear la cesta con la lista de productos
            var shoppingBasket = new ShoppingBasket(shoppingList);

            // Loggear los productos en la cesta
            _logger.LogInformation("\nProducts in the shopping basket:");
            foreach (var item in shoppingBasket.Products)
            {
                _logger.LogInformation($"- {item.Name}: {item.Weight} kg, quantity: {item.Quantity}");
            }

            // Loggear el peso total en la cesta
            _logger.LogInformation($"\nTotal Weight in basket: {shoppingBasket.TotalWeight} kg");
            return shoppingBasket;
        }

        public void OnGet()
        {
            ShoppingList1 = new List<Product>
            {
                new Product("Apple", 5.5, 1),
                new Product("Rice", 3.0, 1),
                new Product("Milk", 2.5, 1),
                new Product("Meat", 10.0, 1),
                new Product("Bread", 1.0, 1),
                new Product("Sugar", 1.0, 4)
            };
            ShoppingBasket1 = ProcessShoppingList(ShoppingList1, "List number 1");

            ShoppingList2 = new List<Product>
            {
                new Product("Apple", 0.5, 3),
                new Product("Rice", 3.0, 2),
                new Product("Milk", 2.5, 1),
                new Product("Meat", 10.0, 1),
                new Product("Bread", 1.0, 1),
                new Product("Sugar", 1.0, 1)
            };
            ShoppingBasket2 = ProcessShoppingList(ShoppingList2, "List number 2");

            ShoppingList3 = new List<Product>
            {
                new Product("Apple", 0.5, 3),
                new Product("Rice", 3.0, 2),
                new Product("Milk", 2.5, 1),
                new Product("Meat", 10.0, 2),
                new Product("Bread", 1.0, 1),
                new Product("Sugar", 1.0, 1)
            };
            ShoppingBasket3 = ProcessShoppingList(ShoppingList3, "List number 3");
        }
    }
}