﻿namespace RafaelHernandezGomez.Model.Product
{
    public class Product
    {
        public string Name { get; set; }
        public double Weight { get; set; }
        public int Quantity { get; set; }

        public Product(string name, double weight, int quantity)
        {
            Name = name;
            Weight = weight;
            Quantity = quantity;
        }
    }
}