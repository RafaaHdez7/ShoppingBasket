﻿namespace RafaelHernandezGomez.Model.ShoppingBasket
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using RafaelHernandezGomez.Model.Product;

    public class ShoppingBasket
    {
        private const double MaxWeight = 20.0;
        public List<Product> Products { get; set; }
        public double TotalWeight { get; private set; }

        public ShoppingBasket()
        {
            Products = new List<Product>();
            TotalWeight = 0.0;
        }
        public ShoppingBasket(List<Product> products)
        {
            Products = FillBasket(products);
        }

        // Método para llenar la cesta respetando el límite de peso
        public List<Product> FillBasket(List<Product> shoppingList)
        {
            var sortedList = shoppingList.OrderByDescending(product => product.Weight).ToList();
            var currentBasket = new List<Product>();

            foreach (var product in sortedList)
            {
                foreach (var repetition in Enumerable.Range(0, product.Quantity))
                {
                    if (TotalWeight + product.Weight <= MaxWeight)
                    {
                        //if the product is almost in the list, quantity ++ else, add a new product
                        var existingProduct = currentBasket.FirstOrDefault(p => p.Name == product.Name);

                        if (existingProduct != null)
                        {
                            existingProduct.Quantity++;
                        }
                        else
                        {
                            currentBasket.Add(new Product(product.Name, product.Weight, 1));
                        }

                        TotalWeight += product.Weight;
                    }
                    else
                    {
                        break;
                    }
                }
            }

            return currentBasket;
        }
    }
}